# server.py
from mcp.server.fastmcp import FastMCP

# Create an MCP server
mcp = FastMCP("Inventory")

# Add an inventory check tool


# Add a weekly sales tool


mcp.run()